package com.example.shop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
